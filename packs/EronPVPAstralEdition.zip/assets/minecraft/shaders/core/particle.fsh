#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec2 texCoord0;
in vec4 vertexColor;
in vec4 rawColor;
in vec4 lightColor;

out vec4 fragColor;

void main() {
    vec4 tex = texture(Sampler0, texCoord0);
    int marker = int(tex.a * 255.0 + 0.5);
    if (marker != 255 && marker % 4 != 2) {
        discard;
    }
    vec4 tint = vertexColor;
    if (marker == 255) {
        // opaque texel: a block particle (the mace smash dust, also block crumbs), drawn solid blue
        float lum = dot(tex.rgb, vec3(0.299, 0.587, 0.114));
        tex = vec4(0.12 + lum * 0.1, 0.42 + lum * 0.2, 0.95, 1.0);
        tint = vec4(lightColor.rgb, rawColor.a * lightColor.a);
    }
    if (marker == 250) {
        // vanilla tints totem glitter green (3 in 4) or yellow (1 in 4)
        vec3 totem = rawColor.r > rawColor.g * 0.72 ? vec3(0.25, 1.0, 0.5) : vec3(0.62, 0.2, 0.95);
        tint = vec4(totem * lightColor.rgb, rawColor.a * lightColor.a);
    }
    vec4 color = tex * tint * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
